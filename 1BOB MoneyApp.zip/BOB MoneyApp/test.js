let testVar = 100;
console.log(testVar);